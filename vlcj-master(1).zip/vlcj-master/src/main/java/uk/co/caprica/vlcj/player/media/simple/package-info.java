/**
 * Simple media, i.e. that represented by a Media Resource Locator (MRL).
 */
package uk.co.caprica.vlcj.player.media.simple;
