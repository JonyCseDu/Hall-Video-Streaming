/**
 * Provides various version-related classes.
 */
package uk.co.caprica.vlcj.version;
