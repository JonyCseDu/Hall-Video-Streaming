/**
 * Provides access to native media service discovery.
 */
package uk.co.caprica.vlcj.player.discoverer;
