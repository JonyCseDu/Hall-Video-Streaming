/**
 * Provides various utility classes for applications running in an X-Windows
 * environment.
 */
package uk.co.caprica.vlcj.runtime.x;
