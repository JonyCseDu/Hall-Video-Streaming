/**
 * Provides higher-level components used to create basic media players with the
 * minimum of application code.
 */
package uk.co.caprica.vlcj.component;
