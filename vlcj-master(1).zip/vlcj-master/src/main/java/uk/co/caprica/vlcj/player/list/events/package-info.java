/**
 * A mechanism to encapsulate native media list player events and dispatch
 * notifications to event listeners.
 */
package uk.co.caprica.vlcj.player.list.events;
