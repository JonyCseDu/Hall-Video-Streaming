/**
 * Default implementations for commonly needed media player conditions used
 * with the synchronous programming framework.
 */
package uk.co.caprica.vlcj.player.condition.conditions;
