print ("LUA> Hello Lua")
io.flush ()
